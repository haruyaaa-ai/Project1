package com.example.project1

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var txtSelectedDate: TextView
    private lateinit var txtSelectedTime: TextView
    private lateinit var btnPickDate: Button
    private lateinit var btnPickTime: Button
    private lateinit var btnReminder: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtSelectedDate = findViewById(R.id.txtSelectedDate)
        txtSelectedTime = findViewById(R.id.txtSelectedTime)
        btnPickDate = findViewById(R.id.btnPickDate)
        btnPickTime = findViewById(R.id.btnPickTime)
        btnReminder = findViewById(R.id.btnReminder)

        btnPickDate.setOnClickListener {
            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)

            val dpd = DatePickerDialog(this, { _, y, m, d ->
                txtSelectedDate.text = "$d/${m + 1}/$y"
            }, year, month, day)
            dpd.show()
        }

        btnPickTime.setOnClickListener {
            val c = Calendar.getInstance()
            val hour = c.get(Calendar.HOUR_OF_DAY)
            val minute = c.get(Calendar.MINUTE)

            val tpd = TimePickerDialog(this, { _, h, m ->
                txtSelectedTime.text = String.format("%02d:%02d", h, m)
            }, hour, minute, true)
            tpd.show()
        }

        btnReminder.setOnClickListener {
            val date = txtSelectedDate.text
            val time = txtSelectedTime.text

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Set Reminder")
            builder.setMessage("Set reminder for $date at $time?")
            builder.setPositiveButton("Yes") { _, _ ->
                Toast.makeText(this, "Reminder set!", Toast.LENGTH_SHORT).show()
            }
            builder.setNegativeButton("Cancel", null)
            builder.show()
        }
    }
}
